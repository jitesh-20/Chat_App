var express = require('express');
var router = express.Router();
var User = require('../models/user');













module.exports = router;